// Main Javascript for Futuristic TECHATHON Website

gsap.registerPlugin(ScrollTrigger);

document.addEventListener('DOMContentLoaded', () => {
    const navbar = document.querySelector('.navbar');
    const orbMaster = document.querySelector('.orb-master-container');
    const orbWrapper = document.querySelector('.orb-wrapper');
    const orb = document.querySelector('.orb');
    const orbGlow = document.querySelector('.orb-glow');
    const ambientGlow = document.querySelector('.ambient-glow');
    const canvas = document.getElementById('particle-canvas');
    const ctx = canvas.getContext('2d');

    let mouseX = 0;
    let mouseY = 0;
    let orbX = 0;
    let orbY = 0;

    // Set canvas size
    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    // Navbar Entrance
    gsap.to(navbar, {
        y: 0,
        opacity: 1,
        duration: 1.5,
        ease: "power4.out",
        delay: 0.5
    });

    // Navbar Scroll Effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Mouse Tracking
    window.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;

        // Subtle ambient glow movement
        gsap.to(ambientGlow, {
            duration: 2,
            x: (mouseX - window.innerWidth / 2) * 0.05,
            y: (mouseY - window.innerHeight / 2) * 0.05,
            ease: "power2.out"
        });
    });

    // Orb Follow Effect (Magnetic)
    function updateOrb() {
        const targetX = (mouseX - window.innerWidth / 2) * 0.1;
        const targetY = (mouseY - window.innerHeight / 2) * 0.1;

        orbX += (targetX - orbX) * 0.05;
        orbY += (targetY - orbY) * 0.05;

        gsap.set(orbWrapper, {
            x: orbX,
            y: orbY
        });

        requestAnimationFrame(updateOrb);
    }
    updateOrb();

    // --- SCROLL ANIMATIONS ---

    // 1. Orb Transition from Hero to Details
    gsap.to(orbMaster, {
        scrollTrigger: {
            trigger: ".hero",
            start: "top top",
            end: "bottom top",
            scrub: 1.5,
            immediateRender: false
        },
        left: "75%", // Move to right side
        scale: 0.8,  // Shrink slightly
        rotation: 15, // Rotate slightly
        ease: "power2.inOut"
    });

    // 2. Hero Content Fade Out
    gsap.to(".hero-content", {
        scrollTrigger: {
            trigger: ".hero",
            start: "center center",
            end: "bottom top",
            scrub: true
        },
        opacity: 0,
        y: -100,
        filter: "blur(20px)",
        ease: "power2.in"
    });

    // 3. Card Reveals (Staggered Fade Up + Blur)
    const cards = gsap.utils.toArray('.info-card');
    cards.forEach((card, i) => {
        gsap.from(card, {
            scrollTrigger: {
                trigger: card,
                start: "top 85%",
                toggleActions: "play none none reverse"
            },
            opacity: 0,
            y: 50,
            filter: "blur(15px)",
            duration: 1.2,
            delay: i * 0.2,
            ease: "power3.out"
        });
    });

    // 4. Horizontal Text Parallax
    gsap.to(".text-track", {
        scrollTrigger: {
            trigger: ".details",
            start: "top bottom",
            end: "bottom top",
            scrub: 2
        },
        x: -200,
        ease: "none"
    });

    // 5. Grid Section Reveal
    gsap.from(".grid-container", {
        scrollTrigger: {
            trigger: ".grid-section",
            start: "top 80%",
            end: "bottom center",
            scrub: 1
        },
        scale: 0.8,
        opacity: 0,
        filter: "blur(20px)",
        ease: "power2.out"
    });

    // 6. Gallery Section - Orb Transition
    gsap.to(orbMaster, {
        scrollTrigger: {
            trigger: ".gallery-section",
            start: "top center",
            end: "bottom center",
            scrub: 1.5
        },
        left: "25%", // Move to left side
        opacity: 0.8,
        scale: 0.7,
        filter: "blur(20px)",
        ease: "power2.inOut"
    });

    // 7. Gallery Cards Reveal (Staggered)
    const galleryCards = gsap.utils.toArray('.gallery-card');
    galleryCards.forEach((card, i) => {
        gsap.from(card, {
            scrollTrigger: {
                trigger: card,
                start: "top 90%",
                toggleActions: "play none none reverse"
            },
            opacity: 0,
            y: 100,
            filter: "blur(20px)",
            duration: 1.5,
            delay: (i % 2) * 0.1, 
            ease: "power3.out"
        });
    });

    // 8. Dissolve Section - Orb Behavior (Move above text)
    gsap.to(orbMaster, {
        scrollTrigger: {
            trigger: ".dissolve-section",
            start: "top bottom",
            end: "top top",
            scrub: 1.5
        },
        left: "50%",
        top: "30%", // Move higher
        opacity: 1,
        scale: 1,
        filter: "blur(0px)",
        ease: "power3.inOut"
    });

    // Slow zoom out (shrinking) while emitting
    gsap.to(orbMaster, {
        scrollTrigger: {
            trigger: ".dissolve-section",
            start: "top top",
            end: "bottom bottom",
            scrub: 3 // Very slow zoom out
        },
        scale: 0.1,
        opacity: 0,
        filter: "blur(40px)",
        ease: "none"
    });

    gsap.to(".dissolve-text", {
        scrollTrigger: {
            trigger: ".dissolve-section",
            start: "top 40%",
            end: "center center",
            scrub: 1
        },
        opacity: 1,
        y: -30,
        filter: "blur(0px)",
        ease: "power3.out"
    });

    // 9. Image Emission System
    const emissionContainer = document.getElementById('emission-container');
    const images = [
        'https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=200',
        'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=200',
        'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?w=200',
        'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=200',
        'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=200'
    ];

    function spawnImage() {
        if (!ScrollTrigger.isInViewport(".dissolve-section")) return;

        const img = document.createElement('img');
        img.src = images[Math.floor(Math.random() * images.length)];
        img.className = 'floating-image';
        
        // Random size - smaller to look like they start from inside
        const size = 30 + Math.random() * 50;
        img.style.width = `${size}px`;
        img.style.height = `${size * 1.2}px`;
        
        emissionContainer.appendChild(img);

        // Animation
        const angle = Math.random() * Math.PI * 2;
        const distance = 400 + Math.random() * 600;
        const tx = Math.cos(angle) * distance;
        const ty = Math.sin(angle) * distance;

        gsap.fromTo(img, 
            { 
                x: 0, y: 0, 
                opacity: 0, 
                scale: 0,
                rotation: 0
            },
            {
                x: tx, y: ty,
                opacity: 0.8,
                scale: 1,
                rotation: (Math.random() - 0.5) * 180,
                duration: 5 + Math.random() * 5,
                ease: "power2.out",
                onStart: () => {
                    gsap.to(img, { opacity: 0.8, duration: 0.5 });
                },
                onComplete: () => {
                    gsap.to(img, {
                        opacity: 0,
                        scale: 0.5,
                        duration: 1.5,
                        onComplete: () => img.remove()
                    });
                }
            }
        );
    }

    // Faster spawn loop for more density
    setInterval(spawnImage, 250);

    // 10. Morphing Monolith Logic
    const monolithPath = document.querySelector('#morph-path');
    const monolithSection = document.querySelector('.monolith-section');
    const monolithSVG = document.querySelector('.monolith-svg');
    const monolithText = document.querySelector('.monolith-text');
    
    const plusPath = "M 40 10 L 60 10 L 60 40 L 90 40 L 90 60 L 60 60 L 60 90 L 40 90 L 40 60 L 10 60 L 10 40 L 40 40 Z";
    const squirclePath = "M 10 10 L 90 10 L 90 10 L 90 10 L 90 90 L 90 90 L 90 90 L 10 90 L 10 90 L 10 90 L 10 10 L 10 10 Z";

    let tl = gsap.timeline({
        scrollTrigger: {
            trigger: monolithSection,
            start: "top top",
            end: "bottom bottom",
            scrub: 1,
            pin: true
        }
    });

    tl.to(monolithPath, {
        attr: { d: squirclePath },
        duration: 1,
        ease: "power2.inOut"
    }, 0);

    tl.to(monolithSVG, {
        scale: 50,
        opacity: 0,
        duration: 2,
        ease: "expo.in"
    }, 0.5);

    tl.to(".monolith-gradient-overlay", {
        opacity: 1,
        scale: 1.5,
        duration: 1.5
    }, 0.5);

    tl.to(monolithText, {
        opacity: 1,
        filter: "blur(0px)",
        y: 0,
        duration: 1,
        ease: "power3.out"
    }, 1.5);

    // Liquid Text Interaction
    window.addEventListener('mousemove', (e) => {
        if (!ScrollTrigger.isInViewport(monolithSection)) return;
        
        const rect = monolithText.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        const dist = Math.hypot(e.clientX - centerX, e.clientY - centerY);
        const maxDist = 400;
        
        if (dist < maxDist) {
            const power = (1 - dist / maxDist) * 20;
            const moveX = (e.clientX - centerX) / 10;
            const moveY = (e.clientY - centerY) / 10;
            
            gsap.to(monolithText, {
                x: moveX,
                y: moveY,
                skewX: power,
                textShadow: `0 0 ${power * 2}px rgba(255,255,255,0.5)`,
                duration: 0.6,
                ease: "power2.out"
            });
        } else {
            gsap.to(monolithText, {
                x: 0,
                y: 0,
                skewX: 0,
                textShadow: "0 0 0px rgba(255,255,255,0)",
                duration: 1
            });
        }
    });

    // Populate Grid Dots
    const dotContainer = document.getElementById('grid-dots');
    const rows = 4; // 3 rows = 4 horizontal lines
    const cols = 6; // 5 columns = 6 vertical lines

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            const dot = document.createElement('div');
            dot.className = 'grid-dot';
            dot.style.top = `${(r / (rows - 1)) * 100}%`;
            dot.style.left = `${(c / (cols - 1)) * 100}%`;
            
            // Random delay for pulsing
            dot.style.animationDelay = `${Math.random() * 4}s`;
            
            dotContainer.appendChild(dot);
        }
    }

    // Orb behavior in Grid Section
    gsap.to(orbMaster, {
        scrollTrigger: {
            trigger: ".grid-section",
            start: "top 80%",
            end: "top 20%",
            scrub: 1
        },
        opacity: 0,
        scale: 0.5,
        filter: "blur(50px)",
        ease: "power2.inOut"
    });

    // --- PARTICLE SYSTEM ---
    const particles = [];
    const particleCount = 70;

    class Particle {
        constructor() {
            this.init();
        }
        init() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2 + 0.5;
            this.speedX = (Math.random() - 0.5) * 0.4;
            this.speedY = (Math.random() - 0.5) * 0.4;
            this.opacity = Math.random() * 0.4 + 0.1;
        }
        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            if (this.x > canvas.width) this.x = 0;
            if (this.x < 0) this.x = canvas.width;
            if (this.y > canvas.height) this.y = 0;
            if (this.y < 0) this.y = canvas.height;
        }
        draw() {
            ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
    }

    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animateParticles);
    }
    animateParticles();

    // --- ORB INTERACTIONS ---
    orbWrapper.addEventListener('mouseenter', () => {
        gsap.to(orb, {
            scale: 1.1,
            filter: "blur(0px) brightness(1.3) contrast(1.1)",
            duration: 0.6,
            ease: "back.out(2)"
        });
        gsap.to(orbGlow, {
            scale: 1.3,
            opacity: 0.9,
            duration: 0.6,
            filter: "blur(70px)"
        });
    });

    orbWrapper.addEventListener('mouseleave', () => {
        gsap.to(orb, {
            scale: 1,
            filter: "blur(1px) brightness(1) contrast(1)",
            duration: 0.8,
            ease: "power2.inOut"
        });
        gsap.to(orbGlow, {
            scale: 1,
            opacity: 0.6,
            duration: 0.8,
            filter: "blur(60px)"
        });
    });

    orbWrapper.addEventListener('mousemove', (e) => {
        const rect = orbWrapper.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        
        gsap.to(orb, {
            rotationY: x * 40,
            rotationX: -y * 40,
            duration: 0.5,
            ease: "power1.out"
        });

        gsap.to(orb, {
            backgroundPosition: `${50 + x * 40}% ${50 + y * 40}%`,
            duration: 0.8
        });
    });
});
