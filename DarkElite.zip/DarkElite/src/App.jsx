import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Cpu, 
  Code, 
  Globe, 
  Zap, 
  Terminal, 
  ShieldCheck, 
  Users, 
  Trophy,
  Menu,
  X,
  ChevronRight,
  Github,
  Twitter,
  Linkedin
} from 'lucide-react';
import heroImage from './assets/hero.png';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Tracks', href: '#tracks' },
    { name: 'Schedule', href: '#schedule' },
    { name: 'Sponsors', href: '#sponsors' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass-card py-3 m-4' : 'bg-transparent py-6'}`}>
      <div className="container flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Cpu className="text-cyan-400" size={32} />
          <span className="font-orbitron text-xl font-bold tracking-tighter">
            TECH<span className="text-cyan-400">ATHON</span>
          </span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium hover:text-cyan-400 transition-colors uppercase tracking-wider"
            >
              {link.name}
            </a>
          ))}
          <button className="btn-primary text-xs px-6 py-2">Register Now</button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-4 right-4 mt-2 glass-card p-6 md:hidden flex flex-col gap-4"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                className="text-lg font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <button className="btn-primary w-full mt-2">Register Now</button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => (
  <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
    <div className="container relative z-10 grid md:grid-cols-2 gap-12 items-center">
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="inline-block px-4 py-1 rounded-full bg-cyan-400/10 border border-cyan-400/30 text-cyan-400 text-xs font-bold uppercase tracking-widest mb-6">
          The Future of Innovation
        </div>
        <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
          CODE THE <br />
          <span className="gradient-text">IMPOSSIBLE</span>
        </h1>
        <p className="text-slate-400 text-lg mb-8 max-w-lg">
          Join 500+ developers, designers, and innovators for 48 hours of building, 
          learning, and competing for prizes worth $10,000.
        </p>
        <div className="flex flex-wrap gap-4">
          <button className="btn-primary flex items-center gap-2">
            Join Techathon <ChevronRight size={18} />
          </button>
          <button className="px-8 py-3 rounded-lg border border-slate-700 hover:bg-slate-800 transition-all font-semibold uppercase text-sm tracking-wider">
            View Schedule
          </button>
        </div>
        
        <div className="mt-12 grid grid-cols-3 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-cyan-400">48H</h3>
            <p className="text-xs text-slate-500 uppercase tracking-widest">Hacking</p>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-cyan-400">20+</h3>
            <p className="text-xs text-slate-500 uppercase tracking-widest">Prizes</p>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-cyan-400">500+</h3>
            <p className="text-xs text-slate-500 uppercase tracking-widest">Hackers</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 0.2 }}
        className="relative"
      >
        <div className="relative z-10 glass-card p-2 rounded-2xl overflow-hidden neon-border">
          <img 
            src={heroImage} 
            alt="Techathon Hero" 
            className="w-full h-auto rounded-xl opacity-90 hover:scale-105 transition-transform duration-700"
          />
        </div>
        {/* Decorative elements */}
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-cyan-500/20 blur-3xl rounded-full"></div>
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-purple-500/20 blur-3xl rounded-full"></div>
      </motion.div>
    </div>

    {/* Background Grid/Lines */}
    <div className="absolute inset-0 z-0 opacity-20 pointer-events-none" 
      style={{ 
        backgroundImage: 'radial-gradient(#1e293b 1px, transparent 1px)', 
        backgroundSize: '40px 40px' 
      }}>
    </div>
  </section>
);

const Tracks = () => {
  const tracks = [
    { 
      icon: <Zap className="text-yellow-400" />, 
      title: 'AI & Machine Learning', 
      desc: 'Build the next generation of intelligent systems and predictive models.' 
    },
    { 
      icon: <Globe className="text-blue-400" />, 
      title: 'Web3 & Blockchain', 
      desc: 'Explore decentralized apps, smart contracts, and the future of the web.' 
    },
    { 
      icon: <ShieldCheck className="text-green-400" />, 
      title: 'Cybersecurity', 
      desc: 'Develop innovative solutions to protect data and digital infrastructure.' 
    },
    { 
      icon: <Terminal className="text-purple-400" />, 
      title: 'Cloud Native', 
      desc: 'Scale applications using modern cloud architectures and microservices.' 
    }
  ];

  return (
    <section id="tracks" className="bg-slate-900/50">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">INNOVATION <span className="text-cyan-400">TRACKS</span></h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Choose your challenge and build something that changes the world. 
            Industry experts will be there to mentor you throughout.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tracks.map((track, index) => (
            <motion.div 
              key={index}
              whileHover={{ y: -10 }}
              className="glass-card p-8 border-t-2 border-transparent hover:border-cyan-400 transition-all duration-300"
            >
              <div className="mb-6 inline-block p-3 rounded-xl bg-slate-800/50">
                {track.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{track.title}</h3>
              <p className="text-slate-400 text-sm">{track.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="py-12 border-t border-slate-800">
    <div className="container">
      <div className="flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Cpu className="text-cyan-400" size={24} />
            <span className="font-orbitron text-lg font-bold">TECHATHON</span>
          </div>
          <p className="text-slate-500 text-sm max-w-xs">
            The premier technology marathon for innovators, creators, and world-changers.
          </p>
        </div>
        
        <div className="flex gap-6">
          <a href="#" className="text-slate-400 hover:text-cyan-400 transition-colors"><Github size={20} /></a>
          <a href="#" className="text-slate-400 hover:text-cyan-400 transition-colors"><Twitter size={20} /></a>
          <a href="#" className="text-slate-400 hover:text-cyan-400 transition-colors"><Linkedin size={20} /></a>
        </div>
      </div>
      <div className="mt-12 pt-8 border-t border-slate-800/50 text-center text-slate-600 text-xs">
        &copy; 2026 TECHATHON. ALL RIGHTS RESERVED. DESIGNED FOR THE FUTURE.
      </div>
    </div>
  </footer>
);

function App() {
  return (
    <div className="min-h-screen bg-[#020617] text-white selection:bg-cyan-500/30">
      <div className="bg-blob blob-1"></div>
      <div className="bg-blob blob-2"></div>
      
      <Navbar />
      <main>
        <Hero />
        <Tracks />
        {/* Additional sections can be added here */}
      </main>
      <Footer />
    </div>
  );
}

export default App;
